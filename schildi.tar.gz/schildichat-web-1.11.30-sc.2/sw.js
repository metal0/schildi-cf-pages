self.addEventListener("fetch", () => {});
